
var CMSserviceURL = window.localStorage.getItem("CMSserviceURL");
var AirportCity = window.localStorage.getItem("SHED_AIRPORT_CITY");
var CMSserviceURL = window.localStorage.getItem("CMSserviceURL");
var GHAExportFlightserviceURL = window.localStorage.getItem("GHAExportFlightserviceURL");
var UserId = window.localStorage.getItem("UserID");
var UserName = window.localStorage.getItem("UserName");
var TotPackages;
var OldLocationId;
var OldLocationPieces;
var strXmlStore;
var locPieces;
var html;
var Flight_SeqNo
var ULD_SeqNo 
var location 
var LocationID
var availableLoc = [];
$(function () {
     GetETVLocation();
    
    if (window.localStorage.getItem("RoleExpIntlMvmt") == '0') {
        window.location.href = 'EXP_Dashboard.html';
    }

    $('#txtScanID').keypress(function (event) {
        var keycode = (event.keyCode ? event.keyCode : event.which);
        if (keycode == '13') {
            $('body').mLoading({
                text: "Please Wait..",
            });
            if ($("#txtScanID").val() == '') {
                $("body").mLoading('hide');
                errmsg = "Please Scan No.</br>";
                $.alert(errmsg);
                return;
            } else {
      
            //    <Root><ULDNo>AKE12346BA</ULDNo><AirportCity>DEL</AirportCity><UserID>1</UserID></Root>
             
                GetETVULDDetails();
            }
        }
        //Stop the event from propogation to other handlers
        //If this line will be removed, then keypress event handler attached 
        //at document level will also be triggered
        event.stopPropagation();
    });

});

function SaveShipmentInternalMovement() {

    var connectionStatus = navigator.onLine ? 'online' : 'offline'
    var errmsg = "";

    var ULDNo = $('#txtScanID').val();
    var FromLoc = $('#txtFromLocation').val().toUpperCase();
    if(FromLoc == ""){
       var oldLocCode = "";
       var oldETVLocCode = "";
    }else{
        var oldLocCode = FromLoc;
        var oldETVLocCode = LocationID;
    }
    var newLocCode = $('#txtNewLocation').val().toUpperCase();
    let index = availableLoc.indexOf(newLocCode);

    var newLocCodeID =index+1;

    if (ULDNo == "") {

        errmsg = "Please enter Scan Id.</br>";
        $.alert(errmsg);
        return;

    }

    if ($('#txtNewLocation').val() == "") {

        errmsg = "Please enter new location</br>";
        $.alert(errmsg);
        return;

    }
     
    _InputXML = "<Root><ULDSeqNo>" + ULD_SeqNo + "</ULDSeqNo><AirportCity>" + AirportCity + "</AirportCity><UserID>" + UserId + "</UserID><LocationCode>" + newLocCode + "</LocationCode><ETVLocationID>" + newLocCodeID+ "</ETVLocationID><OldLocationCode>" + oldLocCode + "</OldLocationCode><OldETVLocationID>"+ oldETVLocCode +"</OldETVLocationID><Flight_SeqNo>" + Flight_SeqNo + "</Flight_SeqNo></Root>";
  
    if (errmsg == "" && connectionStatus == "online") {
        $.ajax({
            type: "POST",
            url: GHAExportFlightserviceURL + "/UpdateULDLocation",
            data: JSON.stringify({"InputXML": _InputXML}),
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            beforeSend: function doStuff() {
                //$('.dialog-background').css('display', 'block');
                $('body').mLoading({
                    text: "Please Wait..",
                });
            },
            success: function (response) {
               
                $("body").mLoading('hide');
                $.alert(response.d);
               
                
                //window.location.reload();
                //clearALL();
                GetETVULDDetails();
                $('#txtNewLocation').val(''); 
            },
            error: function (msg) {
                $("body").mLoading('hide');
                $.alert('Some error occurred while saving data');
            }
        });
        return false;
    }

}





function GetETVLocation() {

    var connectionStatus = navigator.onLine ? 'online' : 'offline'
    var errmsg = "";

 
    
    _InputXML = "<Root><LocationCode></LocationCode></Root>";
     
    if (errmsg == "" && connectionStatus == "online") {
        $.ajax({
            type: 'POST',
            url: GHAExportFlightserviceURL + "/GetETVLocation",
            data: JSON.stringify({"InputXML": _InputXML}),
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            beforeSend: function doStuff() {
                //$('.dialog-background').css('display', 'block');
                $('body').mLoading({
                    text: "Loading..",
                });
            },
            success: function (response) {
                $("body").mLoading('hide');
                var str = response.d;
                console.log(str)
                strXmlStore = str;

                if (str != null && str != "") {
                                    
                    var xmlDoc = $.parseXML(str);

                

                        availableLoc.length = 0;
                        $(xmlDoc).find('Table').each(function (index) {
                            availableLoc.push($(this).find('LocationCode').text());
                        });
                        
                        $("#txtNewLocation").autocomplete({
                            source: availableLoc,
                            minLength: 1,
                            select: function (event, ui) {
                            
                                log(ui.item ?
                                    "Selected: " + ui.item.label :
                                    "Nothing selected, input was " + this.value);
                            },
                            open: function () {
                                $(this).removeClass("ui-corner-all").addClass("ui-corner-top");
                            },
                            close: function () {
                                $(this).removeClass("ui-corner-top").addClass("ui-corner-all");
                            }
                        });
        

                }
                else {
                    errmsg = 'Shipment does not exists';
                    $.alert(errmsg);
                }

            },
            error: function (msg) {
                $("body").mLoading('hide');
                var r =(msg.responseText);
                // $.alert(r.Message);
            }
        });
    }
    else if (connectionStatus == "offline") {
        $("body").mLoading('hide');
        $.alert('No Internet Connection!');
    }
    else if (errmsg != "") {
        $("body").mLoading('hide');
        $.alert(errmsg);
    }
    else {
        $("body").mLoading('hide');
    }
}



function GetETVULDDetails() {

    var connectionStatus = navigator.onLine ? 'online' : 'offline'
    var errmsg = "";

  

    // if (AWBNo != '' && AWBNo.length != '11') {
    //     errmsg = "Please enter valid AWB No.";
    //     $.alert(errmsg);
    //     return;
    // }
    //  _InputXML = "Root><ULDNo>AKE12346BA</ULDNo><AirportCity>DEL</AirportCity><UserID>1</UserID></Root>";
    HideLoader();
    var ULDNo = $("#txtScanID").val();
      var inputxml = "<Root><ULDNo>" + ULDNo + "</ULDNo><AirportCity>" + AirportCity + "</AirportCity><UserID>" + UserId + "</UserID></Root>"
    if (errmsg == "" && connectionStatus == "online") {
        $.ajax({
            type: 'POST',
            url: GHAExportFlightserviceURL + "/GetETVULDDetails",
            data: JSON.stringify({"InputXML": inputxml}),
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            beforeSend: function doStuff() {
                //$('.dialog-background').css('display', 'block');
                $('body').mLoading({
                    text: "Loading..",
                });
            },
            success: function (response) {
                $("body").mLoading('hide');
                var str = response.d;
console.log("str =", str)
                strXmlStore = str;

                if (str != null && str != "") {
                                    
                    var xmlDoc = $.parseXML(str);

                    $(xmlDoc).find('Table').each(function (index) {

                        if ($(this).find('LocCode').text() != '')
                        {
                            $.alert($(this).find('LocCode').text());
                            return;
                        }
                        $("#txtNOG").val($(this).find('nog').text());
                        $("#txtUldNo").val($(this).find('ULDNo').text());
                        var LocationStatusColor =  ($(this).find('LocationStatusColor').text());
                         $("#statusULD").text($(this).find('LocationStatus').text()).css({'color':"" + LocationStatusColor + ""});
                         $("#txtOrigin").val($(this).find('Origin').text());
                        $("#txtDestination").val($(this).find('Destination').text());

                         $("#txtFlightNo").val($(this).find('Flight_SeqNo').text());
                        $("#txtFlightDate").val($(this).find('FlightDateTime').text());
                        // $("#txtFromLocation").text($(this).find('Location').text());
                        $("#txtFromLocation").val($(this).find('Location').text());
                    
                        Flight_SeqNo =  ($(this).find('Flight_SeqNo').text());
                        ULD_SeqNo =  ($(this).find('ULD_SeqNo').text());
                        LocationID =  ($(this).find('LocationID').text());

                        
                        // var newOption = $('<option></option>');
                        // newOption.val(EWRval).text(EWRno);
                        // newOption.appendTo('#ddlEWRno');
                        
                    });                    

                }
                else {
                    errmsg = 'Shipment does not exists';
                    $.alert(errmsg);
                }

            },
            error: function (msg) {
                $("body").mLoading('hide');
                var r = jQuery.parseJSON(msg.responseText);
                // $.alert(r.Message);
            }
        });
    }
    else if (connectionStatus == "offline") {
        $("body").mLoading('hide');
        $.alert('No Internet Connection!');
    }
    else if (errmsg != "") {
        $("body").mLoading('hide');
        $.alert(errmsg);
    }
    else {
        $("body").mLoading('hide');
    }
}



function clearALL() {
    $('#txtAWBNo').val('');
    $('#txtFromLocation').val('');
    $('#txtTotalPkg').val('');
    $('#txtMovePackages').val('');
    $('#txtNewLocation').val(''); 
    $('#divAddTestLocation').empty();

    $('#ddlEWRno').empty();
    $('#txtOrigin').val('');
    $('#txtDestination').val('');
    $('#txtAWBNo').focus();
    $('#txtScanID').val('');
    $('#txtUldNo').val('');
    $('#statusULD').text('');
    $('#txtFlightNo').val('');
    $('#txtFlightDate').val('');
    $(".ibiSuccessMsg").text('');
    
}

function clearBeforePopulate() {
    $('#txtFromLocation').val('');
    $('#txtTotalPkg').val('');
    $('#txtMovePackages').val('');
    $('#txtNewLocation').val('');

    $('#txtOrigin').val('');
    $('#txtDestination').val('');
    $('#txtCommodity').val('');
    $('#txtTotalPkg').val('');
    $('#txtLoader').val('');

    $('#divAddLocation').empty();
    html = '';
}


function ClearError(ID) {
    $("#" + ID).css("background-color", "#e7ffb5");
}

function log(message) {
    $("<div>").text(message).prependTo("#log");
    $("#log").scrollTop(0);
}


    function checkLocation() {

        var newLocCode = $('#txtNewLocation').val().toUpperCase();
        var connectionStatus = navigator.onLine ? 'online' : 'offline'
        var errmsg = "";
    if(newLocCode == ""){
        $(".ibiSuccessMsg").text('');
        return;
    }
     
        
        _InputXML = "<Root><LocationCode>" + newLocCode+ "</LocationCode></Root>";
         
        if (errmsg == "" && connectionStatus == "online") {
            $.ajax({
                type: 'POST',
                url: GHAExportFlightserviceURL + "/VerifyETVLocation",
                data: JSON.stringify({"InputXML": _InputXML}),
                contentType: "application/json; charset=utf-8",
                dataType: "json",
                beforeSend: function doStuff() {
                    //$('.dialog-background').css('display', 'block');
                    $('body').mLoading({
                        text: "Loading..",
                    });
                },
                success: function (response, xhr, textStatus) {
                    //console.log(response.d);
                    HideLoader();
                    var str = response.d;
                    if (str != null && str != "" && str != "<NewDataSet />") {
                        $("#btnDiv").show('slow');
                        var xmlDoc = $.parseXML(str);
    
                    $(xmlDoc).find('Table').each(function (index) {
                        Status = $(this).find('Status').text();
                        StrMessage = $(this).find('OutMsg').text();
                        if (Status == 'E') {
                            $(".ibiSuccessMsg").text(StrMessage).css({ "color": "Red", "font-weight": "bold" });
                       
                        } else {
                            $(".ibiSuccessMsg").text('');
                        }
                    });
    
                } else {
                    $("body").mLoading('hide');
                    //errmsg = "WDO No. not found</br>";
                    //$.alert(errmsg);
                    //return;
                }
            },
            error: function (xhr, textStatus, errorThrown) {
                $("body").mLoading('hide');
                //alert('Server not responding...');
                console.log(xhr.responseText);
                alert(xhr.responseText);
            }
        });
    }
}

